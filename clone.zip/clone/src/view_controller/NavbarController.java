package view_controller;

import view.NavbarView;

public class NavbarController {
	
	public NavbarController() {
		
	}

}
