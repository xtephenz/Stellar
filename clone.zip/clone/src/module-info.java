module sesi10 {
	opens database;
	opens view;
	opens model;
	opens main;
	
	requires java.sql;
	requires javafx.graphics;
	requires javafx.controls;
	requires javafx.base;
}